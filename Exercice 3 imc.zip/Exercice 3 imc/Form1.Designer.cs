﻿namespace Exercice_3__reédit_
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAdd = new System.Windows.Forms.Button();
            this.textValeur1 = new System.Windows.Forms.TextBox();
            this.textValeur2 = new System.Windows.Forms.TextBox();
            this.TextImc = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnQuitter = new System.Windows.Forms.Button();
            this.btnEffacer = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(76, 199);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(73, 72);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "=";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // textValeur1
            // 
            this.textValeur1.Location = new System.Drawing.Point(199, 72);
            this.textValeur1.Name = "textValeur1";
            this.textValeur1.Size = new System.Drawing.Size(157, 22);
            this.textValeur1.TabIndex = 1;
            this.textValeur1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textValeur2
            // 
            this.textValeur2.Location = new System.Drawing.Point(199, 127);
            this.textValeur2.Name = "textValeur2";
            this.textValeur2.Size = new System.Drawing.Size(157, 22);
            this.textValeur2.TabIndex = 2;
            this.textValeur2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // TextImc
            // 
            this.TextImc.Location = new System.Drawing.Point(199, 221);
            this.TextImc.Name = "TextImc";
            this.TextImc.Size = new System.Drawing.Size(157, 22);
            this.TextImc.TabIndex = 3;
            this.TextImc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(208, 262);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 29);
            this.label1.TabIndex = 5;
            this.label1.Text = "resultat IMC";
            // 
            // btnQuitter
            // 
            this.btnQuitter.Image = global::Exercice_3__reédit_.Properties.Resources.Stop1NormalRed_26963;
            this.btnQuitter.Location = new System.Drawing.Point(466, 166);
            this.btnQuitter.Name = "btnQuitter";
            this.btnQuitter.Size = new System.Drawing.Size(117, 77);
            this.btnQuitter.TabIndex = 8;
            this.btnQuitter.UseVisualStyleBackColor = true;
            this.btnQuitter.Click += new System.EventHandler(this.btnQuitter_Click);
            // 
            // btnEffacer
            // 
            this.btnEffacer.Image = global::Exercice_3__reédit_.Properties.Resources.gui_eraser_icon_157160;
            this.btnEffacer.Location = new System.Drawing.Point(466, 72);
            this.btnEffacer.Name = "btnEffacer";
            this.btnEffacer.Size = new System.Drawing.Size(117, 77);
            this.btnEffacer.TabIndex = 7;
            this.btnEffacer.UseVisualStyleBackColor = true;
            this.btnEffacer.Click += new System.EventHandler(this.btnEffacer_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 16);
            this.label2.TabIndex = 9;
            this.label2.Text = "Entrez votre poids";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(41, 133);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 16);
            this.label3.TabIndex = 10;
            this.label3.Text = "Entrez votre taille";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(703, 360);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnQuitter);
            this.Controls.Add(this.btnEffacer);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TextImc);
            this.Controls.Add(this.textValeur2);
            this.Controls.Add(this.textValeur1);
            this.Controls.Add(this.btnAdd);
            this.Name = "Form1";
            this.Text = "Calcul IMC";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox textValeur1;
        private System.Windows.Forms.TextBox textValeur2;
        private System.Windows.Forms.TextBox TextImc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnEffacer;
        private System.Windows.Forms.Button btnQuitter;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

