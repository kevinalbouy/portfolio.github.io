﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercice_3__reédit_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private TextBox GetTextImc()
        {
            return TextImc;
        }

        private TextBox CalculIMC()
        {
            return TextImc;
        }

        /** clique sur le bouton ajouter
         * permet d'ajouter les 2 nombres */

        private void btnAdd_Click(object sender, EventArgs e)
        {
            double valeur1, valeur2;
            double santé;
            if (double.TryParse(textValeur1.Text, out valeur1) && double.TryParse(textValeur2.Text, out valeur2))
            {
                if (valeur1 <= 0 || valeur2 <= 0)
                {
                    MessageBox.Show("Erreur : Le poids et la taille doivent être supérieurs à 0.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;

                    TextImc.Text = (valeur1 / (valeur2 * valeur2)).ToString();
                    if (double.TryParse(TextImc.Text, out santé))
                    {
                        if (santé <= 18.5)
                        {
                            MessageBox.Show("Insuffisance pondérale (maigreur)", "Resultat", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else if (santé < 25)
                        {
                            MessageBox.Show("Corpulence normale", "Resultat", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else if (santé < 30)
                        {
                            MessageBox.Show("Surpoids", "Resultat", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else if (santé < 35)
                        {
                            MessageBox.Show("Obésité modéré", "Resultat", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else if (santé < 40)
                        {
                            MessageBox.Show("Obésité sévère", "Resultat", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else if (santé > 40)
                        {
                            MessageBox.Show("Obésité morbide", "Resultat", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Erreur de calcul de l'IMC.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Veuillez entrer des nombres valides.", "Erreur de saisie", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }





            }
        }



        /** clique sur le bouton effacer
        * permet d'effacer les 2 nombres */


        private void btnEffacer_Click(object sender, EventArgs e)
        {
            textValeur1.Text = "";
            textValeur2.Text = "";
            TextImc.Text = "";
        }

        /** clique sur le bouton quitter
      * permet de quitter l'application */

        private void btnQuitter_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }

}

